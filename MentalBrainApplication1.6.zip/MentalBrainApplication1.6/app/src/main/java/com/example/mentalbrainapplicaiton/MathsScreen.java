package com.example.mentalbrainapplicaiton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MathsScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maths_screen);
    }

    public void openMentalMaths(View view) {
        Intent intent = new Intent(this, MentalMaths.class);
        startActivity(intent);
    }

    public void openMathsQuiz(View view) {
        Intent intent = new Intent(this, MathsQuiz.class);
        startActivity(intent);
    }

    public void openMain(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


    public void openAccountDetails(View view) {

        Intent intent = new Intent(this, UserRegister.class);
        startActivity(intent);
    }
}
